<?php

class Operation {
    
}